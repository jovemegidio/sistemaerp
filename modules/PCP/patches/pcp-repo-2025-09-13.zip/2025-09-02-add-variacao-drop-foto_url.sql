-- Migration: add variacao column, drop foto_url from produtos
-- IMPORTANT: backup your DB before running.
-- 1) Backup recommendation (run from shell):
-- mysqldump -u root -p aluforce_vendas produtos > produtos_backup_2025_09_02.sql

-- 2) Add 'variacao' column (nullable)
ALTER TABLE produtos
  ADD COLUMN variacao VARCHAR(255) DEFAULT NULL;

-- 3) If you want to copy existing data from foto_url into variacao (unlikely), uncomment and adjust:
-- UPDATE produtos SET variacao = foto_url WHERE foto_url IS NOT NULL AND (variacao IS NULL OR variacao = '');

-- 4) Drop foto_url column
ALTER TABLE produtos
  DROP COLUMN foto_url;

-- 5) Optional: verify
-- SELECT COLUMN_NAME, COLUMN_TYPE FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = 'aluforce_vendas' AND TABLE_NAME = 'produtos';

-- Rollback plan: restore from the backup file created in step 1
-- mysql -u root -p aluforce_vendas < produtos_backup_2025_09_02.sql
