// auth-redirect.js - verify session by probing a protected endpoint using credentials so HttpOnly cookies are respected
(async function(){
    // don't run on the login page itself
    if (window.location.pathname === '/login.html') return;

    // short timeout helper for fetch
    const probe = async (url, timeout = 2000) => {
        const ac = new AbortController();
        const id = setTimeout(() => ac.abort(), timeout);
        try {
            const res = await fetch(url, { method: 'GET', credentials: 'include', signal: ac.signal });
            clearTimeout(id);
            return res;
        } catch (e) {
            clearTimeout(id);
            throw e;
        }
    };

    try {
        const resp = await probe('/api/pcp/me', 2500);
        console.debug('[auth-redirect] probe /api/pcp/me status=', resp && resp.status);
        if (resp && resp.ok) {
            // authenticated, nothing to do
            return;
        }
    } catch (err) {
        console.debug('[auth-redirect] probe error', err && err.message ? err.message : err);
        // network/probe error – treat as unauthenticated
    }

    // not authenticated — redirect to login
    window.location.href = '/login.html';
})();
