-- Migration: add descricao column to produtos if missing and populate from nome
-- Safe to run multiple times.

SET @db := 'aluforce_vendas';

-- Add column if not exists using information_schema to support older MySQL
-- This will add the column only if it does not already exist
SET @exists = (
  SELECT COUNT(*) FROM information_schema.columns
  WHERE table_schema = @db AND table_name = 'produtos' AND column_name = 'descricao'
);
SELECT @exists as descricao_exists;
-- If @exists = 0 then add the column
SET @s = IF(@exists = 0, 'ALTER TABLE produtos ADD COLUMN descricao VARCHAR(255) NULL', 'SELECT "skip"');
PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- Populate descricao from nome when descricao is NULL or empty
UPDATE produtos SET descricao = nome WHERE (descricao IS NULL OR descricao = '') AND (nome IS NOT NULL AND nome <> '');

-- Optional: keep descricao in sync for existing rows where descricao differs and it's acceptable
-- UPDATE produtos SET descricao = nome WHERE descricao <> nome AND (nome IS NOT NULL AND nome <> '');
