const express = require('express');
const cors = require('cors');
const path = require('path');
const mysql = require('mysql2/promise');
const http = require('http');
const { Server } = require('socket.io');
const crypto = require('crypto');

// Try to load bcryptjs once at startup for faster checks in login
let bcrypt = null;
try {
    bcrypt = require('bcryptjs');
    console.log('[INIT] bcryptjs loaded');
} catch (e) {
    console.log('[INIT] bcryptjs not installed or failed to load');
}

const app = express();
// Allow overriding the port via environment variable to avoid killing other services
// Default remains 3001 for compatibility
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3001;

// --- CONFIGURAÇÃO DA LIGAÇÃO À BASE DE DADOS ---
const db = mysql.createPool({
    host: 'localhost',
    user: 'root',
    password: '@dminalu',
    database: 'aluforce_vendas', // banco ajustado conforme solicitado
    port: 3306,
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
});

// Middlewares
app.use(cors({ origin: true, credentials: true }));
app.use(express.json());
// Serve ficheiros estáticos diretamente da raiz do projecto (index.html, login.html, css, js, imagens)
app.use(express.static(__dirname));

// Serve user profile images from /avatars with sensible caching and allowed extensions
// Place images in the project folder `avatars/` (e.g. avatars/clemerson.jpg)
app.use('/avatars', express.static(path.join(__dirname, 'avatars'), {
    maxAge: '1d', // cache for a day in clients
    extensions: ['jpg', 'jpeg', 'png', 'webp', 'gif']
}));

// Serve a favicon to avoid 404 noise from browsers requesting /favicon.ico
app.get('/favicon.ico', (req, res) => {
    res.sendFile(path.join(__dirname, 'Favicon Aluforce.png'));
});

// Simple in-memory session store (for dev). Keys are session ids stored in cookie 'pcp_session'
const sessions = new Map();

function getSessionIdFromReq(req) {
    const cookie = req.headers && req.headers.cookie;
    if (!cookie) return null;
    const m = cookie.match(/pcp_session=([^;]+)/);
    return m ? m[1] : null;
}

function authRequired(req, res, next) {
    const sid = getSessionIdFromReq(req);
    if (!sid || !sessions.has(sid)) return res.status(401).json({ message: 'Não autenticado' });
    req.user = sessions.get(sid).user;
    next();
}

// --- ROTAS DA API ---

// Rota de Login

    // Criar servidor HTTP e Socket.IO para notificações em tempo real
    const httpServer = http.createServer(app);
    const io = new Server(httpServer, {
        cors: { origin: true }
    });

    // Helper: broadcast materiais atuais
    async function broadcastMaterials() {
        try {
            const [rows] = await db.query("SELECT * FROM materiais ORDER BY descricao ASC");
            io.emit('materials_changed', rows);
        } catch (err) {
            console.error('Erro ao broadcast materials:', err.message);
        }
    }

    // Helper: broadcast produtos atuais
    async function broadcastProducts() {
        try {
            const [rows] = await db.query("SELECT * FROM produtos ORDER BY descricao ASC");
            io.emit('products_changed', rows);
        } catch (err) {
            console.error('Erro ao broadcast products:', err.message);
        }
    }

    // Quando cliente conectar, podemos enviar lista inicial
    io.on('connection', (socket) => {
        console.log('Cliente Socket.IO conectado:', socket.id);
        // Envia estado atual dos materiais
        (async () => {
            try {
                const [rows] = await db.query("SELECT * FROM materiais ORDER BY descricao ASC");
                socket.emit('materials_changed', rows);
                // Envia estado atual dos produtos
                try {
                    const [prods] = await db.query("SELECT * FROM produtos ORDER BY descricao ASC");
                    socket.emit('products_changed', prods);
                } catch (prodErr) {
                    console.warn('Não foi possível enviar produtos iniciais:', prodErr.message);
                }
            } catch (err) {
                console.error('Erro ao enviar materiais iniciais:', err.message);
            }
        })();
    });

app.post('/api/pcp/login', async (req, res) => {
    const { email, password } = req.body; // 'email' may contain username in the UI
    try {
        console.log(`[LOGIN] attempt for identifier=${email}`);
        // Try to find user by several possible identifier columns, but perform
        // each lookup separately to avoid SQL errors when a column doesn't exist
        const identifierCols = ['email', 'nome', 'login', 'usuario', 'username'];
        let user = null;
        for (const col of identifierCols) {
            try {
                const sql = `SELECT * FROM usuarios_pcp WHERE ${col} = ? LIMIT 1`;
                const [rows] = await db.query(sql, [email]);
                if (rows && rows.length > 0) { user = rows[0]; break; }
            } catch (e) {
                // Ignore unknown-column errors and continue with next candidate
                if (e && e.code === 'ER_BAD_FIELD_ERROR') {
                    continue;
                }
                throw e;
            }
        }

        if (!user) {
            console.log('[LOGIN] user not found for identifier=', email);
            return res.status(401).json({ message: 'Email/usuário não encontrado.' });
        }

            console.log('[LOGIN] found user id=', user.id, 'identifier match.');
            const stored = (user.senha || user.password || '').toString();
            const masked = stored ? `${stored.slice(0,4)}...len=${stored.length}` : '(empty)';
            console.log('[LOGIN] stored password meta=', masked);

            // If bcrypt is available and stored password looks like a bcrypt hash, prefer bcrypt compare
                if (bcrypt && typeof stored === 'string' && stored.match(/^\$2[aby]\$/)) {
                console.log('[LOGIN] attempting bcrypt compare (preferred)');
                try {
                    const ok = await bcrypt.compare(password, stored);
                    console.log('[LOGIN] bcrypt compare result=', ok);
                    if (ok) {
                        const sid = crypto.randomBytes(16).toString('hex');
                        sessions.set(sid, { user, created: Date.now() });
                        res.setHeader('Set-Cookie', `pcp_session=${sid}; HttpOnly; Path=/; SameSite=Lax`);
                        return res.json({ message: 'Login bem-sucedido!', userData: user });
                    }
                } catch (e) {
                    console.error('[LOGIN] bcrypt compare error:', e && e.message ? e.message : e);
                }
                // If bcrypt compare fails, fall through to plaintext compare as a last resort
                console.log('[LOGIN] bcrypt compare failed or not matched; attempting plaintext as fallback');
            }

            // direct compare (plain text) — many installations store plain passwords
            console.log('[LOGIN] attempting plaintext compare (fallback)');
            if (stored === password) {
                console.log('[LOGIN] plaintext match');
                const sid = crypto.randomBytes(16).toString('hex');
                sessions.set(sid, { user, created: Date.now() });
                res.setHeader('Set-Cookie', `pcp_session=${sid}; HttpOnly; Path=/; SameSite=Lax`);
                return res.json({ message: 'Login bem-sucedido!', userData: user });
            }
            console.log('[LOGIN] plaintext mismatch');

        // not matched
        return res.status(401).json({ message: 'Email ou senha inválidos.' });
    } catch (error) {
        console.error('Erro no login:', error);
        res.status(500).json({ message: 'Erro no servidor.' });
    }
});

// Protected sample endpoints for Dashboard / Prazos / Custos
app.get('/api/pcp/dashboard', authRequired, async (req, res) => {
    try {
        // sample aggregated data: counts and some recent pedidos
        const [pedidos] = await db.query('SELECT id, cliente, produto_id, quantidade, status, data_pedido FROM pedidos ORDER BY data_pedido DESC LIMIT 10');
        const [totals] = await db.query('SELECT COUNT(*) as total_pedidos FROM pedidos');
        res.json({ totals: totals[0], recentPedidos: pedidos });
    } catch (err) {
        console.error('Dashboard error:', err.message);
        res.status(500).json({ message: 'Erro ao buscar dados do dashboard.' });
    }
});

app.get('/api/pcp/prazos', authRequired, async (req, res) => {
    try {
        // show orders with nearest deadlines
        const [rows] = await db.query("SELECT id, codigo_produto, descricao_produto, data_previsao_entrega, status FROM ordens_producao ORDER BY data_previsao_entrega ASC LIMIT 30");
        res.json(rows);
    } catch (err) {
        console.error('Prazos error:', err.message);
        res.status(500).json({ message: 'Erro ao buscar prazos.' });
    }
});

app.get('/api/pcp/custos', authRequired, async (req, res) => {
    try {
        // simple cost overview: sum of pedido quantities * sample cost per product (join if exists)
        const [rows] = await db.query("SELECT p.id, p.descricao, p.custo_unitario, p.quantidade_estoque FROM produtos p ORDER BY p.descricao ASC LIMIT 50");
        res.json(rows);
    } catch (err) {
        console.error('Custos error:', err.message);
        res.status(500).json({ message: 'Erro ao buscar custos.' });
    }
});

// Rota para buscar todas as Ordens de Produção
app.get('/api/pcp/ordens', async (req, res) => {
    try {
        const [rows] = await db.query("SELECT * FROM ordens_producao ORDER BY data_previsao_entrega ASC");
        res.json(rows);
    } catch (error) {
        console.error("Erro ao buscar ordens:", error);
        res.status(500).json({ message: "Erro ao buscar ordens." });
    }
});

// Rota para criar uma nova Ordem de Produção
app.post('/api/pcp/ordens', async (req, res) => {
    const { codigo_produto, descricao_produto, quantidade, data_previsao_entrega, observacoes } = req.body;
    const sql = "INSERT INTO ordens_producao (codigo_produto, descricao_produto, quantidade, data_previsao_entrega, observacoes, status) VALUES (?, ?, ?, ?, ?, 'A Fazer')";
    try {
        const [result] = await db.query(sql, [codigo_produto, descricao_produto, quantidade, data_previsao_entrega, observacoes]);
        res.status(201).json({ message: "Ordem criada com sucesso!", id: result.insertId });
    } catch (error) {
        console.error("Erro ao criar ordem:", error);
        res.status(500).json({ message: "Erro ao criar ordem." });
    }
});

// Rota para atualizar o STATUS de uma Ordem de Produção
app.put('/api/pcp/ordens/:id/status', async (req, res) => {
    const { id } = req.params;
    const { status } = req.body;
    try {
        const [result] = await db.query("UPDATE ordens_producao SET status = ? WHERE id = ?", [status, id]);
        if (result.affectedRows > 0) {
            res.json({ message: "Status atualizado com sucesso!" });
        } else {
            res.status(404).json({ message: "Ordem não encontrada." });
        }
    } catch (error) {
        console.error("Erro ao atualizar status:", error);
        res.status(500).json({ message: "Erro ao atualizar status." });
    }
});


// --- NOVAS ROTAS PARA GESTÃO DE MATERIAIS ---

// Rota para criar um novo material
app.post('/api/pcp/materiais', async (req, res) => {
    const { codigo_material, descricao, unidade_medida, quantidade_estoque, fornecedor_padrao } = req.body;
    const sql = "INSERT INTO materiais (codigo_material, descricao, unidade_medida, quantidade_estoque, fornecedor_padrao) VALUES (?, ?, ?, ?, ?)";
    try {
        const [result] = await db.query(sql, [codigo_material, descricao, unidade_medida, quantidade_estoque, fornecedor_padrao]);
    res.status(201).json({ message: "Material criado com sucesso!", id: result.insertId });
    // Broadcast para clientes conectados
    broadcastMaterials();
    } catch (error) {
        console.error("Erro ao criar material:", error);
        res.status(500).json({ message: "Erro ao criar material.", error: error.message });
    }
});

// Rota para buscar todos os materiais
app.get('/api/pcp/materiais', async (req, res) => {
    try {
        const [rows] = await db.query("SELECT * FROM materiais ORDER BY descricao ASC");
        res.json(rows);
    } catch (error) {
        console.error("Erro ao buscar materiais:", error);
        res.status(500).json({ message: "Erro ao buscar materiais." });
    }
});

// Rota para buscar todos os produtos
// Observação: assume-se que exista a tabela `produtos` no banco `aluforce_vendas`.
app.get('/api/pcp/produtos', async (req, res) => {
    try {
        // support pagination: ?page=1&limit=6
    let page = parseInt(req.query.page, 10) || 1;
    let limit = parseInt(req.query.limit, 10) || 10;
        if (page < 1) page = 1;
        if (limit < 1) limit = 10;
        const offset = (page - 1) * limit;

    const q = (req.query.q || '').trim();
    const like = `%${q}%`;

        // fetch column metadata so client can mirror fields and build safe queries
        let columns = [];
        try {
            const [cols] = await db.query('SHOW COLUMNS FROM produtos');
            columns = Array.isArray(cols) ? cols.map(c => c.Field) : [];
        } catch (e) {
            // if table missing or permission issues, respond gracefully
            console.error('produtos columns lookup failed:', e && e.message ? e.message : e);
            return res.status(500).json({ message: 'Erro ao acessar tabela produtos.' });
        }

        const has = (name) => columns.includes(name);
        const orderColumn = has('descricao') ? 'descricao' : (has('nome') ? 'nome' : (has('codigo') ? 'codigo' : 'id'));

        // fetch rows with limit (optionally filtered by q) using only existing searchable columns
        let rows = [];
        let total = 0;
        if (q) {
            const whereParts = [];
            const params = [];
            if (has('codigo')) { whereParts.push('codigo LIKE ?'); params.push(like); }
            if (has('descricao')) { whereParts.push('descricao LIKE ?'); params.push(like); }
            if (has('nome')) { whereParts.push('nome LIKE ?'); params.push(like); }
            if (has('variacao')) { whereParts.push('variacao LIKE ?'); params.push(like); }

            if (whereParts.length === 0) {
                // nothing to search against
                rows = [];
                total = 0;
            } else {
                const sql = `SELECT * FROM produtos WHERE ${whereParts.join(' OR ')} ORDER BY ${orderColumn} ASC LIMIT ? OFFSET ?`;
                params.push(limit, offset);
                const [rs] = await db.query(sql, params);
                rows = rs;
                // count
                const countSql = `SELECT COUNT(*) AS total FROM produtos WHERE ${whereParts.join(' OR ')}`;
                const [countRes] = await db.query(countSql, params.slice(0, params.length - 2));
                total = countRes && countRes[0] ? countRes[0].total : 0;
            }
        } else {
            const sql = `SELECT * FROM produtos ORDER BY ${orderColumn} ASC LIMIT ? OFFSET ?`;
            const [rs] = await db.query(sql, [limit, offset]);
            rows = rs;
            const [countRes] = await db.query('SELECT COUNT(*) AS total FROM produtos');
            total = countRes && countRes[0] ? countRes[0].total : 0;
        }

        // try to normalize variacao column to JSON arrays for clients
        let convertedLegacy = false;
        const normalizedRows = (rows || []).map(r => {
            try {
                if (r && typeof r.variacao === 'string') {
                    const raw = r.variacao.trim();
                    if (!raw) { r.variacao = []; }
                    else if (raw.startsWith('[') || raw.startsWith('{')) {
                        try { r.variacao = JSON.parse(raw); } catch (e) { r.variacao = [raw]; convertedLegacy = true; }
                    } else {
                        // legacy CSV or semicolon separated
                        const parts = raw.split(/[,;]+/).map(s => s.trim()).filter(Boolean);
                        r.variacao = parts;
                        convertedLegacy = true;
                    }
                }
                // Backwards compatibility: if client expects 'descricao' but DB has 'nome', map it
                if (!r.descricao && r.nome) {
                    r.descricao = r.nome;
                }
            } catch (e) { /* ignore parse errors */ }
            return r;
        });

    if (convertedLegacy) res.setHeader('X-PCP-Warn', 'variacao-legacy-converted');
    // Ensure columns list includes descricao for clients that expect it
    if (!columns.includes('descricao') && columns.includes('nome')) columns.push('descricao');
    res.json({ page, limit, total, rows: normalizedRows, columns });
    } catch (error) {
        console.error('Erro ao buscar produtos:', error && error.message ? error.message : error);
        // Provide minimal debug info in a separate endpoint for local troubleshooting
        res.status(500).json({ message: 'Erro ao buscar produtos.' });
    }
});

// (debug endpoint removed) - temporary debug endpoint was removed for production safety

// Criar novo produto
app.post('/api/pcp/produtos', async (req, res) => {
    const { codigo, descricao, unidade_medida, quantidade_estoque, custo_unitario, variacao } = req.body;
    try {
        // Require variacao to be an array (or a JSON string that parses to an array).
        // Reject legacy CSV/semicolon strings to enforce consistency.
        let variacaoForDb = null;
        if (typeof variacao === 'undefined' || variacao === null) {
            variacaoForDb = null;
        } else if (Array.isArray(variacao)) {
            variacaoForDb = JSON.stringify(variacao);
        } else if (typeof variacao === 'string') {
            const v = variacao.trim();
            if (v.length === 0) {
                variacaoForDb = null;
            } else {
                // try to parse JSON string
                try {
                    const parsed = JSON.parse(v);
                    if (!Array.isArray(parsed)) {
                        return res.status(400).json({ message: 'Campo variacao deve ser um array JSON. Envie [] ou {"..."} não é aceito.' });
                    }
                    variacaoForDb = JSON.stringify(parsed);
                } catch (e) {
                    return res.status(400).json({ message: 'Formato de variacao obsoleto. Envie um array JSON (ex: ["A","B"]).' });
                }
            }
        } else {
            // invalid type
            return res.status(400).json({ message: 'Campo variacao inválido. Deve ser um array JSON.' });
        }
        const sql = 'INSERT INTO produtos (codigo, descricao, unidade_medida, quantidade_estoque, custo_unitario, variacao) VALUES (?, ?, ?, ?, ?, ?)';
        const [result] = await db.query(sql, [codigo, descricao, unidade_medida, quantidade_estoque || 0, custo_unitario || 0, variacaoForDb]);
    res.status(201).json({ message: 'Produto criado', id: result.insertId });
        broadcastProducts();
    } catch (err) {
        console.error('Erro ao criar produto:', err.message);
        res.status(500).json({ message: 'Erro ao criar produto.' });
    }
});

// Atualizar produto
app.put('/api/pcp/produtos/:id', async (req, res) => {
    const { id } = req.params;
    const { codigo, descricao, unidade_medida, quantidade_estoque, custo_unitario, variacao } = req.body;
    try {
        // Require variacao to be an array (or a JSON string that parses to an array).
        let variacaoForDb = null;
        if (typeof variacao === 'undefined' || variacao === null) {
            variacaoForDb = null;
        } else if (Array.isArray(variacao)) {
            variacaoForDb = JSON.stringify(variacao);
        } else if (typeof variacao === 'string') {
            const v = variacao.trim();
            if (v.length === 0) {
                variacaoForDb = null;
            } else {
                try {
                    const parsed = JSON.parse(v);
                    if (!Array.isArray(parsed)) {
                        return res.status(400).json({ message: 'Campo variacao deve ser um array JSON.' });
                    }
                    variacaoForDb = JSON.stringify(parsed);
                } catch (e) {
                    return res.status(400).json({ message: 'Formato de variacao obsoleto. Envie um array JSON (ex: ["A","B"]).' });
                }
            }
        } else {
            return res.status(400).json({ message: 'Campo variacao inválido. Deve ser um array JSON.' });
        }
        const sql = 'UPDATE produtos SET codigo = ?, descricao = ?, unidade_medida = ?, quantidade_estoque = ?, custo_unitario = ?, variacao = ? WHERE id = ?';
        const [result] = await db.query(sql, [codigo, descricao, unidade_medida, quantidade_estoque || 0, custo_unitario || 0, variacaoForDb, id]);
        if (result.affectedRows > 0) {
            res.json({ message: 'Produto atualizado' });
            broadcastProducts();
        } else {
            res.status(404).json({ message: 'Produto não encontrado' });
        }
    } catch (err) {
        console.error('Erro ao atualizar produto:', err.message);
        res.status(500).json({ message: 'Erro ao atualizar produto.' });
    }
});

// Excluir produto
app.delete('/api/pcp/produtos/:id', async (req, res) => {
    const { id } = req.params;
    try {
        const [result] = await db.query('DELETE FROM produtos WHERE id = ?', [id]);
        if (result.affectedRows > 0) {
            res.json({ message: 'Produto excluído' });
            broadcastProducts();
        } else {
            res.status(404).json({ message: 'Produto não encontrado' });
        }
    } catch (err) {
        console.error('Erro ao excluir produto:', err.message);
        res.status(500).json({ message: 'Erro ao excluir produto.' });
    }
});

// Rota para buscar um material por id
app.get('/api/pcp/materiais/:id', async (req, res) => {
    const { id } = req.params;
    try {
        const [rows] = await db.query("SELECT * FROM materiais WHERE id = ?", [id]);
        if (rows.length > 0) {
            res.json(rows[0]);
        } else {
            res.status(404).json({ message: 'Material não encontrado.' });
        }
    } catch (error) {
        console.error('Erro ao buscar material por id:', error.message);
        res.status(500).json({ message: 'Erro ao buscar material.' });
    }
});

// Rota para excluir um material
app.delete('/api/pcp/materiais/:id', async (req, res) => {
    const { id } = req.params;
    try {
        const [result] = await db.query('DELETE FROM materiais WHERE id = ?', [id]);
        if (result.affectedRows > 0) {
            res.json({ message: 'Material excluído com sucesso.' });
            broadcastMaterials();
        } else {
            res.status(404).json({ message: 'Material não encontrado.' });
        }
    } catch (error) {
        console.error('Erro ao excluir material:', error.message);
        res.status(500).json({ message: 'Erro ao excluir material.' });
    }
});

// Rota para atualizar um material (incluindo estoque)
app.put('/api/pcp/materiais/:id', async (req, res) => {
    const { id } = req.params;
    const { descricao, unidade_medida, quantidade_estoque, fornecedor_padrao } = req.body;
    try {
        const sql = "UPDATE materiais SET descricao = ?, unidade_medida = ?, quantidade_estoque = ?, fornecedor_padrao = ? WHERE id = ?";
        const [result] = await db.query(sql, [descricao, unidade_medida, quantidade_estoque, fornecedor_padrao, id]);
        if (result.affectedRows > 0) {
            res.json({ message: "Material atualizado com sucesso!" });
            broadcastMaterials();
        } else {
            res.status(404).json({ message: "Material não encontrado." });
        }
    } catch (error) {
        console.error("Erro ao atualizar material:", error);
        res.status(500).json({ message: "Erro ao atualizar material." });
    }
});


// --- NOVAS ROTAS PARA ORDENS DE COMPRA ---

// Rota para criar nova Ordem de Compra
app.post('/api/pcp/ordens-compra', async (req, res) => {
    const { material_id, quantidade, previsao_entrega } = req.body;
    try {
        const sql = "INSERT INTO ordens_compra (material_id, quantidade, data_pedido, previsao_entrega, status) VALUES (?, ?, CURDATE(), ?, 'Pendente')";
        const [result] = await db.query(sql, [material_id, quantidade, previsao_entrega]);
        res.status(201).json({ message: "Ordem de compra criada com sucesso!", id: result.insertId });
        // opcional: reduzir estoque do material correspondente
        try {
            await db.query("UPDATE materiais SET quantidade_estoque = quantidade_estoque - ? WHERE id = ?", [quantidade, material_id]);
        } catch (err) {
            console.error('Erro ao ajustar estoque após ordem de compra:', err.message);
        }
        broadcastMaterials();
    } catch (error) {
        console.error("Erro ao criar ordem de compra:", error);
        res.status(500).json({ message: "Erro ao criar ordem de compra." });
    }
});

// Endpoints para a tabela `pedidos` (se existir) - listar/criar/atualizar
app.get('/api/pcp/pedidos', async (req, res) => {
    try {
        // Some installations may not have a data_pedido column; order by id as a safe fallback
        const [rows] = await db.query('SELECT * FROM pedidos ORDER BY id DESC');
        res.json(rows);
    } catch (err) {
        console.error('Erro ao buscar pedidos:', err.message);
        // Return empty array so frontend can continue working even if table layout differs
        res.json([]);
    }
});

// Return only approved / billed orders (flexible matching on status)
app.get('/api/pcp/pedidos/faturados', async (req, res) => {
    try {
    // support pagination: ?page=1&limit=50
    let page = parseInt(req.query.page,10) || 1;
    let limit = parseInt(req.query.limit,10) || 50;
    if (page < 1) page = 1;
    if (limit < 1) limit = 50;
    const offset = (page - 1) * limit;
    const sql = `SELECT id, valor, descricao, status, created_at, data_prevista, prazo_entrega, cliente_id, empresa_id, produtos_preview, endereco_entrega, municipio_entrega FROM pedidos WHERE (status LIKE '%fatur%' OR status LIKE '%entreg%' OR status LIKE '%aprov%') ORDER BY created_at DESC LIMIT ? OFFSET ?`;
    const [rows] = await db.query(sql, [limit, offset]);
        // produtos_preview may be stored as JSON string; attempt to parse for clients
        const normalized = (rows || []).map(r => {
            try { if (r.produtos_preview && typeof r.produtos_preview === 'string') r.produtos_preview = JSON.parse(r.produtos_preview); } catch (e) {}
            return r;
        });
    // total count for pagination
    const [countRows] = await db.query("SELECT COUNT(*) AS total FROM pedidos WHERE (status LIKE '%fatur%' OR status LIKE '%entreg%' OR status LIKE '%aprov%')");
    const total = countRows && countRows[0] ? countRows[0].total : 0;
    res.json({ page, limit, total, rows: normalized });
    } catch (err) {
        console.error('Erro ao buscar pedidos faturados:', err && err.message ? err.message : err);
        res.json([]);
    }
});

// Return delivery deadlines (prazos) for billed orders (one row per pedido)
app.get('/api/pcp/pedidos/prazos', async (req, res) => {
    try {
    let page = parseInt(req.query.page,10) || 1;
    let limit = parseInt(req.query.limit,10) || 50;
    if (page < 1) page = 1; if (limit < 1) limit = 50;
    const offset = (page - 1) * limit;
    const sql = `SELECT id, cliente_id, descricao, status, created_at, data_prevista, prazo_entrega, produtos_preview, endereco_entrega FROM pedidos WHERE (status LIKE '%fatur%' OR status LIKE '%entreg%' OR status LIKE '%aprov%') ORDER BY data_prevista IS NULL, data_prevista ASC LIMIT ? OFFSET ?`;
    const [rows] = await db.query(sql, [limit, offset]);
    const normalized = (rows || []).map(r => { try { if (r.produtos_preview && typeof r.produtos_preview === 'string') r.produtos_preview = JSON.parse(r.produtos_preview); } catch(e){} return r; });
    const [countRows] = await db.query("SELECT COUNT(*) AS total FROM pedidos WHERE (status LIKE '%fatur%' OR status LIKE '%entreg%' OR status LIKE '%aprov%')");
    const total = countRows && countRows[0] ? countRows[0].total : 0;
    res.json({ page, limit, total, rows: normalized });
    } catch (err) {
        console.error('Erro ao buscar prazos de pedidos:', err && err.message ? err.message : err);
        res.json([]);
    }
});

// Aggregated acompanhamento endpoint to show recent vendas/pedidos and totals
app.get('/api/pcp/acompanhamento', async (req, res) => {
    try {
        // totals and recent pedidos
    const [totalsRows] = await db.query('SELECT COUNT(*) AS total_pedidos FROM pedidos');
    const totals = totalsRows && totalsRows[0] ? totalsRows[0] : { total_pedidos: 0 };
    const [recent] = await db.query(`SELECT id, descricao, status, created_at, produtos_preview, data_prevista FROM pedidos ORDER BY created_at DESC LIMIT 20`);
    const normalized = (recent || []).map(r => { try { if (r.produtos_preview && typeof r.produtos_preview === 'string') r.produtos_preview = JSON.parse(r.produtos_preview); } catch(e){} return r; });
    res.json({ totals, recentPedidos: normalized });
    } catch (err) {
        console.error('Erro no acompanhamento:', err && err.message ? err.message : err);
        res.status(500).json({ totals: { total_pedidos: 0 }, recentPedidos: [] });
    }
});

app.post('/api/pcp/pedidos', async (req, res) => {
    const { cliente, produto_id, quantidade, status } = req.body;
    try {
        const [result] = await db.query('INSERT INTO pedidos (cliente, produto_id, quantidade, data_pedido, status) VALUES (?, ?, ?, CURDATE(), ?)', [cliente, produto_id, quantidade, status || 'Pendente']);
        res.status(201).json({ message: 'Pedido criado', id: result.insertId });
        // atualizar materiais se necessário
        broadcastMaterials();
    } catch (err) {
        console.error('Erro ao criar pedido:', err.message);
        res.status(500).json({ message: 'Erro ao criar pedido.' });
    }
});

app.put('/api/pcp/pedidos/:id', async (req, res) => {
    const { id } = req.params;
    const { status } = req.body;
    try {
        const [result] = await db.query('UPDATE pedidos SET status = ? WHERE id = ?', [status, id]);
        if (result.affectedRows > 0) {
            res.json({ message: 'Pedido atualizado' });
            broadcastMaterials();
        } else {
            res.status(404).json({ message: 'Pedido não encontrado' });
        }
    } catch (err) {
        console.error('Erro ao atualizar pedido:', err.message);
        res.status(500).json({ message: 'Erro ao atualizar pedido.' });
    }
});

// Rota para buscar todas as Ordens de Compra
app.get('/api/pcp/ordens-compra', async (req, res) => {
    const sql = `
        SELECT oc.id, m.codigo_material, m.descricao, oc.quantidade, oc.data_pedido, oc.previsao_entrega, oc.status
        FROM ordens_compra oc
        JOIN materiais m ON oc.material_id = m.id
        ORDER BY oc.data_pedido DESC
    `;
    try {
        const [rows] = await db.query(sql);
        res.json(rows);
    } catch (error) {
        console.error("Erro ao buscar ordens de compra:", error);
        res.status(500).json({ message: "Erro ao buscar ordens de compra." });
    }
});

// Gerar PDF para uma ordem de compra específica
app.get('/api/pcp/ordens-compra/:id/pdf', async (req, res) => {
    const { id } = req.params;
    try {
        // fetch order with material details
        const [rows] = await db.query(
            `SELECT oc.id, oc.quantidade, oc.data_pedido, oc.previsao_entrega, oc.status, m.codigo_material, m.descricao as material_descricao, m.unidade_medida
             FROM ordens_compra oc
             JOIN materiais m ON oc.material_id = m.id
             WHERE oc.id = ? LIMIT 1`, [id]
        );
        if (!rows || rows.length === 0) return res.status(404).json({ message: 'Ordem de compra não encontrada' });
        const ord = rows[0];

        // Lazy load PDFKit
        let PDFDocument;
        try { PDFDocument = require('pdfkit'); } catch (e) { return res.status(500).json({ message: 'Dependência pdfkit não instalada' }); }

        const doc = new PDFDocument({ size: 'A4', margin: 40 });
        res.setHeader('Content-Type', 'application/pdf');
        res.setHeader('Content-Disposition', `inline; filename="ordem_compra_${ord.id}.pdf"`);
        doc.fontSize(16).text('Ordem de Compra', { align: 'center' });
        doc.moveDown();
        doc.fontSize(11).text(`Número: ${ord.id}`);
        doc.text(`Data do Pedido: ${ord.data_pedido ? ord.data_pedido.toISOString().slice(0,10) : ord.data_pedido}`);
        doc.text(`Previsão de Entrega: ${ord.previsao_entrega ? ord.previsao_entrega.toISOString().slice(0,10) : ord.previsao_entrega}`);
        doc.moveDown();
        doc.fontSize(12).text('Material:', { underline: true });
        doc.fontSize(11).text(`Código: ${ord.codigo_material}`);
        doc.text(`Descrição: ${ord.material_descricao}`);
        doc.text(`Unidade: ${ord.unidade_medida || ''}`);
        doc.text(`Quantidade: ${ord.quantidade}`);
        doc.moveDown();
        doc.text('Status: ' + (ord.status || 'Pendente'));

    // Pipe the document to the response before finalizing the PDF stream
    doc.pipe(res);
    doc.end();
    } catch (err) {
        console.error('Erro ao gerar PDF da ordem de compra:', err && err.message ? err.message : err);
        res.status(500).json({ message: 'Erro ao gerar PDF.' });
    }
});


// Inicia o servidor HTTP (com Socket.IO integrado)
// Try to listen on requested port, but if it's already in use, try the next few ports.
function tryListen(startPort, maxTries = 10) {
    let attempt = 0;
    function listenPort(port) {
        attempt++;
        httpServer.listen(port, () => {
            console.log(`Servidor do P.C.P. a correr em http://localhost:${port}`);
        });
        httpServer.once('error', (err) => {
            if (err && err.code === 'EADDRINUSE') {
                console.warn(`Port ${port} em uso, tentando porta ${port + 1}...`);
                if (attempt < maxTries) {
                    // small delay before retrying
                    setTimeout(() => listenPort(port + 1), 200);
                } else {
                    console.error('Não foi possível iniciar o servidor: portas em uso.');
                    process.exit(1);
                }
            } else {
                console.error('Erro ao iniciar o servidor:', err && err.message ? err.message : err);
                process.exit(1);
            }
        });
    }
    listenPort(startPort);
}

tryListen(PORT, 12);

// Buscar produto por id
app.get('/api/pcp/produtos/:id', async (req, res) => {
    const { id } = req.params;
    try {
        const [rows] = await db.query('SELECT * FROM produtos WHERE id = ?', [id]);
        if (rows.length > 0) {
            const r = rows[0];
            // normalize variacao to array for clients (same behaviour as list endpoint)
            try {
                if (r && typeof r.variacao === 'string') {
                    const raw = r.variacao.trim();
                    if (!raw) { r.variacao = []; }
                    else if (raw.startsWith('[') || raw.startsWith('{')) {
                        try { r.variacao = JSON.parse(raw); } catch (e) { r.variacao = [raw]; }
                    } else {
                        const parts = raw.split(/[,;]+/).map(s => s.trim()).filter(Boolean);
                        r.variacao = parts;
                    }
                }
            } catch (e) { /* ignore parse errors */ }
            res.json(r);
        } else res.status(404).json({ message: 'Produto não encontrado' });
    } catch (err) {
        console.error('Erro ao buscar produto:', err.message);
        res.status(500).json({ message: 'Erro ao buscar produto.' });
    }
});

// Busca unificada (server-side) para ordens, materiais e produtos
app.get('/api/pcp/search', async (req, res) => {
    const q = (req.query.q || '').trim();
    const type = (req.query.type || '').trim(); // optional: 'ordem'|'material'|'produto'
    let page = parseInt(req.query.page, 10) || 1;
    let limit = parseInt(req.query.limit, 10) || 25;
    if (!q) return res.json({ ordens: [], materiais: [], produtos: [] });

    // safety bounds
    if (limit > 200) limit = 200;
    if (page < 1) page = 1;
    const offset = (page - 1) * limit;
    const like = `%${q}%`;

    try {
        const result = { ordens: [], materiais: [], produtos: [] };

        // Helper: query ordens
        async function queryOrdens() {
            const [rows] = await db.query(
                `SELECT id, codigo_produto, descricao_produto, quantidade, data_previsao_entrega, status
                 FROM ordens_producao
                 WHERE codigo_produto LIKE ? OR descricao_produto LIKE ?
                 ORDER BY data_previsao_entrega ASC
                 LIMIT ? OFFSET ?`, [like, like, limit, offset]
            );
            return rows;
        }

        async function queryMateriais() {
            const [rows] = await db.query(
                `SELECT id, codigo_material, descricao, unidade_medida, quantidade_estoque
                 FROM materiais
                 WHERE codigo_material LIKE ? OR descricao LIKE ?
                 ORDER BY descricao ASC
                 LIMIT ? OFFSET ?`, [like, like, limit, offset]
            );
            return rows;
        }

        async function queryProdutos() {
            const [rows] = await db.query(
                `SELECT id, codigo, descricao, unidade_medida, quantidade_estoque, custo_unitario
                 FROM produtos
                 WHERE codigo LIKE ? OR descricao LIKE ?
                 ORDER BY descricao ASC
                 LIMIT ? OFFSET ?`, [like, like, limit, offset]
            );
            return rows;
        }

        async function queryPedidos() {
            // search by pedido id (if numeric), cliente (empresa) or produto code/description (join produtos)
            const possibleId = parseInt(q, 10);
            if (!Number.isNaN(possibleId)) {
                const [rows] = await db.query(
                    `SELECT p.id, p.cliente, p.produto_id, p.quantidade, p.status, p.data_pedido, pr.codigo as produto_codigo, pr.descricao as produto_descricao
                     FROM pedidos p
                     LEFT JOIN produtos pr ON p.produto_id = pr.id
                     WHERE p.id = ?
                     ORDER BY p.data_pedido DESC
                     LIMIT ? OFFSET ?`, [possibleId, limit, offset]
                );
                return rows;
            }
            const [rows] = await db.query(
                `SELECT p.id, p.cliente, p.produto_id, p.quantidade, p.status, p.data_pedido, pr.codigo as produto_codigo, pr.descricao as produto_descricao
                 FROM pedidos p
                 LEFT JOIN produtos pr ON p.produto_id = pr.id
                 WHERE p.cliente LIKE ? OR pr.codigo LIKE ? OR pr.descricao LIKE ?
                 ORDER BY p.data_pedido DESC
                 LIMIT ? OFFSET ?`, [like, like, like, limit, offset]
            );
            return rows;
        }

    if (!type || type === 'ordem') result.ordens = await queryOrdens();
    if (!type || type === 'material') result.materiais = await queryMateriais();
    if (!type || type === 'produto') result.produtos = await queryProdutos();
    if (!type || type === 'pedido') result.pedidos = await queryPedidos();

        // counts for pagination/UX
        let ordensTotal = 0, materiaisTotal = 0, produtosTotal = 0;
        try {
            const [ordensCountRows] = await db.query(`SELECT COUNT(*) AS total FROM ordens_producao WHERE codigo_produto LIKE ? OR descricao_produto LIKE ?`, [like, like]);
            ordensTotal = ordensCountRows[0]?.total || 0;
        } catch (e) { ordensTotal = 0; }
        try {
            const [materiaisCountRows] = await db.query(`SELECT COUNT(*) AS total FROM materiais WHERE codigo_material LIKE ? OR descricao LIKE ?`, [like, like]);
            materiaisTotal = materiaisCountRows[0]?.total || 0;
        } catch (e) { materiaisTotal = 0; }
        try {
            const [produtosCountRows] = await db.query(`SELECT COUNT(*) AS total FROM produtos WHERE codigo LIKE ? OR descricao LIKE ?`, [like, like]);
            produtosTotal = produtosCountRows[0]?.total || 0;
        } catch (e) { produtosTotal = 0; }
        // pedidos count
        let pedidosTotal = 0;
        try {
            const [pedidosCountRows] = await db.query(`SELECT COUNT(*) AS total FROM pedidos p LEFT JOIN produtos pr ON p.produto_id = pr.id WHERE p.id = ? OR p.cliente LIKE ? OR pr.codigo LIKE ? OR pr.descricao LIKE ?`, [q, like, like, like]);
            pedidosTotal = pedidosCountRows[0]?.total || 0;
        } catch (e) { pedidosTotal = 0; }

        // include pagination metadata and totals
    res.json({ page, limit, q, results: result, totals: { ordens: ordensTotal, materiais: materiaisTotal, produtos: produtosTotal, pedidos: pedidosTotal } });
    } catch (err) {
        console.error('Erro na busca unificada:', err.message);
        res.status(500).json({ message: 'Erro ao realizar busca.' });
    }
});

// Health endpoint for quick checks
app.get('/health', (req, res) => {
    try {
        res.json({ status: 'ok', pid: process.pid, uptime: process.uptime() });
    } catch (err) {
        res.status(500).json({ status: 'error' });
    }
});

// Internal debug endpoint (temporary) to report server bind info and PID
app.get('/internal-debug', (req, res) => {
    try {
        const addr = httpServer.address();
        res.json({ pid: process.pid, address: addr });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Lightweight endpoint to return current authenticated user (used by client probes)
app.get('/api/pcp/me', authRequired, async (req, res) => {
    try {
        const user = req.user || {};
        // attempt to fetch foto_perfil_url from `funcionarios` table when available
        let foto = null;
        try {
            if (user.email) {
                const [rows] = await db.query('SELECT foto_perfil_url FROM funcionarios WHERE email = ? LIMIT 1', [user.email]);
                if (rows && rows[0] && rows[0].foto_perfil_url) foto = rows[0].foto_perfil_url;
            }
        } catch (e) {
            // ignore lookup errors and continue with other heuristics
            foto = foto || null;
        }
        try {
            if (!foto && user.id) {
                const [rows2] = await db.query('SELECT foto_perfil_url FROM funcionarios WHERE usuario_id = ? LIMIT 1', [user.id]);
                if (rows2 && rows2[0] && rows2[0].foto_perfil_url) foto = rows2[0].foto_perfil_url;
            }
        } catch (e) { /* ignore */ }
        try {
            if (!foto && user.id) {
                const [rows3] = await db.query('SELECT foto_perfil_url FROM funcionarios WHERE id = ? LIMIT 1', [user.id]);
                if (rows3 && rows3[0] && rows3[0].foto_perfil_url) foto = rows3[0].foto_perfil_url;
            }
        } catch (e) { /* ignore */ }

        // return a sanitized subset of user fields (do not expose senha/password)
        const safe = {
            id: user.id,
            email: user.email,
            nome: user.nome,
            role: user.role,
            foto_perfil_url: foto || null
        };
        res.json({ user: safe });
    } catch (err) {
        console.error('/api/pcp/me error:', err && err.message ? err.message : err);
        res.status(500).json({ message: 'Erro ao obter dados do usuário.' });
    }
});

// Logout endpoint: clears session and cookie set by login
app.post('/api/pcp/logout', (req, res) => {
    try {
        const sid = getSessionIdFromReq(req);
        if (sid && sessions.has(sid)) sessions.delete(sid);
        // Clear cookie on client
        res.setHeader('Set-Cookie', 'pcp_session=; HttpOnly; Path=/; Max-Age=0; SameSite=Lax');
        return res.json({ message: 'Logged out' });
    } catch (err) {
        console.error('Logout error:', err && err.message ? err.message : err);
        return res.status(500).json({ message: 'Erro ao deslogar' });
    }
});

// fetch single pedido by id
app.get('/api/pcp/pedidos/:id', async (req, res) => {
    const { id } = req.params;
    try {
        const [rows] = await db.query('SELECT p.*, pr.codigo as produto_codigo, pr.descricao as produto_descricao FROM pedidos p LEFT JOIN produtos pr ON p.produto_id = pr.id WHERE p.id = ?', [id]);
        if (!rows || rows.length === 0) return res.status(404).json({ message: 'Pedido não encontrado' });
        res.json(rows[0]);
    } catch (err) {
        console.error('Erro ao buscar pedido:', err && err.message ? err.message : err);
        res.status(500).json({ message: 'Erro ao buscar pedido.' });
    }
});

// Debug endpoint: return raw rows or error for faturados query (temporary)
app.get('/api/pcp/debug/pedidos-faturados', async (req, res) => {
    try {
        const sql = `SELECT id, valor, descricao, status, created_at, data_prevista, prazo_entrega, cliente_id, empresa_id, produtos_preview, endereco_entrega, municipio_entrega FROM pedidos WHERE (status LIKE '%fatur%' OR status LIKE '%entreg%' OR status LIKE '%aprov%') ORDER BY created_at DESC LIMIT 50`;
        const [rows] = await db.query(sql);
        return res.json({ ok: true, rows: rows.slice(0,10) });
    } catch (err) {
        return res.status(500).json({ ok: false, error: (err && err.message) ? err.message : String(err) });
    }
});
