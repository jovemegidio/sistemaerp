// Test script: verifies produtos table CRUD and variacao column
// Uses mysql2; run with: node migrations/test_produtos_db.js

const mysql = require('mysql2/promise');

(async function(){
  const cfg = {
    host: process.env.DB_HOST || '127.0.0.1',
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASS || '@dminalu',
    database: process.env.DB_NAME || 'aluforce_vendas',
    port: process.env.DB_PORT ? parseInt(process.env.DB_PORT,10) : 3306,
  };
  let conn;
  try {
    console.log('Connecting to DB', cfg.database, 'at', cfg.host);
    conn = await mysql.createConnection(cfg);

    // Check columns
    const [cols] = await conn.query("SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = ? AND TABLE_NAME = 'produtos'", [cfg.database]);
    const colNames = cols.map(r => r.COLUMN_NAME);
    console.log('Columns:', colNames.join(', '));
    if (!colNames.includes('variacao')) throw new Error('coluna variacao não encontrada');
    if (colNames.includes('foto_url')) throw new Error('coluna foto_url ainda presente (esperado removida)');

    // Insert test product
    const code = 'TEST-' + Date.now();
    const descricao = 'Produto de teste';
    const unidade = 'un';
    const qtd = 5;
    const custo = 12.5;
    const variacao = 'Cor:Azul;Tam:M';

    const [ins] = await conn.query('INSERT INTO produtos (codigo, descricao, unidade_medida, quantidade_estoque, custo_unitario, variacao) VALUES (?, ?, ?, ?, ?, ?)', [code, descricao, unidade, qtd, custo, variacao]);
    const id = ins.insertId;
    console.log('Inserted test product id=', id, 'code=', code);

    // Read back
    const [rows] = await conn.query('SELECT id, codigo, descricao, variacao, quantidade_estoque, custo_unitario FROM produtos WHERE id = ?', [id]);
    if (!rows || rows.length === 0) throw new Error('não encontrou produto inserido');
    console.log('Read product:', rows[0]);

    // Update variacao
    const newVar = 'Cor:Vermelho;Tam:L';
    await conn.query('UPDATE produtos SET variacao = ? WHERE id = ?', [newVar, id]);
    const [after] = await conn.query('SELECT variacao FROM produtos WHERE id = ?', [id]);
    console.log('After update variacao =', after[0].variacao);
    if (String(after[0].variacao) !== newVar) throw new Error('Atualização de variacao falhou');

    // Search by variacao
    const q = '%Vermelho%';
    const [found] = await conn.query('SELECT id, codigo FROM produtos WHERE variacao LIKE ? LIMIT 5', [q]);
    console.log('Search results by variacao LIKE', q, ':', found.map(r=>r.codigo));
    if (!Array.isArray(found)) throw new Error('Busca por variacao falhou');

    // Clean up: delete test product
    await conn.query('DELETE FROM produtos WHERE id = ?', [id]);
    console.log('Deleted test product id=', id);

    console.log('\nAll DB tests passed.');
    process.exit(0);
  } catch (err) {
    console.error('TEST FAILED:', err && err.message ? err.message : err);
    process.exit(2);
  } finally {
    if (conn) await conn.end();
  }
})();
