document.addEventListener('DOMContentLoaded', () => {
  const loginForm = document.getElementById('login-form');
  const errorMessageDiv = document.getElementById('error-message');
  const submitBtn = document.getElementById('login-submit-btn');

  if (!loginForm) return;

  // Toggle loading state on the submit button (shows spinner, hides text)
  function setLoading(loading) {
  if (!submitBtn) return;
  submitBtn.disabled = loading;
  submitBtn.setAttribute('aria-busy', loading ? 'true' : 'false');
  // Toggle the loading class; CSS controls spinner visibility and layout
  submitBtn.classList.toggle('loading', loading);
  // Avoid inline style manipulation so CSS can manage layout and animation
  }

  loginForm.addEventListener('submit', async (event) => {
    event.preventDefault();
    if (submitBtn && submitBtn.disabled) return; // prevent double submit

    if (errorMessageDiv) {
      errorMessageDiv.classList.remove('visible');
      errorMessageDiv.textContent = '';
      errorMessageDiv.setAttribute('aria-live', 'polite');
    }

    setLoading(true);

    const usernameEl = document.getElementById('username');
    const passwordEl = document.getElementById('password');
    const username = usernameEl ? usernameEl.value.trim() : '';
    const password = passwordEl ? passwordEl.value : '';

    if (!username || !password) {
      if (errorMessageDiv) {
        errorMessageDiv.textContent = 'Preencha email e senha.';
        errorMessageDiv.classList.add('visible');
      }
      setLoading(false);
      return;
    }

    try {
      // Use the PCP login endpoint which sets an HttpOnly session cookie
      const response = await fetch('/api/pcp/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ email: username, password })
      });

      // Try to parse JSON safely
      let data = {};
      try { data = await response.json(); } catch (e) { data = {}; }

      if (!response.ok) {
        // server provided message preferred
        const msg = (data && data.message) ? data.message : `Erro de autenticação (${response.status})`;
        throw new Error(msg);
      }

      // Login bem-sucedido: redireciona para a área principal (index.html)
      window.location.href = '/index.html';
    } catch (error) {
      if (errorMessageDiv) {
        errorMessageDiv.textContent = error && error.message ? error.message : 'Erro ao efetuar login';
        errorMessageDiv.classList.add('visible');
      }
      console.debug('[login] error', error);
    } finally {
      setLoading(false);
    }
  });
});
