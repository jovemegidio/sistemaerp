// quick check of new endpoints using node-fetch
const fetch = require('node-fetch');
(async ()=>{
  const base = 'http://localhost:3001/api/pcp';
  try {
    for (const p of ['pedidos/faturados','pedidos/prazos','acompanhamento']){
      const url = `${base}/${p}`;
      const res = await fetch(url);
      console.log(url, '->', res.status);
      const body = await res.text();
      console.log('body (truncated):', body.slice(0,200));
    }
    process.exit(0);
  } catch (err) { console.error('check failed', err); process.exit(2); }
})();
