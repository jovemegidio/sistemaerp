-- schema_materiais.sql
-- Script para criar a tabela `materiais` usada pelo servidor PCP
-- Ajuste o database/schema conforme necessário antes de executar.

CREATE TABLE IF NOT EXISTS materiais (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  codigo_material VARCHAR(100) NOT NULL,
  descricao VARCHAR(512) NOT NULL,
  unidade_medida VARCHAR(50) DEFAULT NULL,
  quantidade_estoque DECIMAL(12,3) NOT NULL DEFAULT 0,
  fornecedor_padrao VARCHAR(255) DEFAULT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY ux_codigo_material (codigo_material)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Exemplo de dados iniciais (opcional)
INSERT INTO materiais (codigo_material, descricao, unidade_medida, quantidade_estoque, fornecedor_padrao)
VALUES
  ('MAT-001','Fio de alumínio 1.5mm','m', 100.000, 'Fornecedor A'),
  ('MAT-002','Chapas de alumínio 2mm','un', 50.000, 'Fornecedor B');
