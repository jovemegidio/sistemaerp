const http = require('http');
const endpoints = [
  '/api/pcp/pedidos/faturados',
  '/api/pcp/pedidos/prazos',
  '/api/pcp/acompanhamento'
];
const host = 'localhost';
const port = process.env.PORT || 3001;

function fetchPath(path) {
  return new Promise((resolve) => {
    const opts = { hostname: host, port, path, method: 'GET', timeout: 3000 };
    const req = http.request(opts, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => resolve({ status: res.statusCode, body: data.slice(0,2000) }));
    });
    req.on('error', (e) => resolve({ error: e.message }));
    req.on('timeout', () => { req.abort(); resolve({ error: 'timeout' }); });
    req.end();
  });
}

(async ()=>{
  for (const p of endpoints) {
    const r = await fetchPath(p);
    console.log(p, '=>', r.status || r.error);
    if (r.body) console.log('body:', r.body.replace(/\n/g,' ').slice(0,800));
    console.log('---');
  }
})();
