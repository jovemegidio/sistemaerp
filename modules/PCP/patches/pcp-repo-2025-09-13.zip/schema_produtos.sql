-- schema_produtos.sql
-- Script para criar a tabela `produtos` usada pelo PCP/portal
-- Ajuste o database/schema conforme necessário antes de executar.

CREATE TABLE IF NOT EXISTS produtos (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  codigo VARCHAR(100) NOT NULL,
  descricao VARCHAR(512) NOT NULL,
  unidade VARCHAR(50) DEFAULT NULL,
  quantidade DECIMAL(12,3) NOT NULL DEFAULT 0,
  preco DECIMAL(12,2) DEFAULT NULL,
  fornecedor VARCHAR(255) DEFAULT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY ux_codigo (codigo)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Exemplo de dados iniciais (opcional)
INSERT INTO produtos (codigo, descricao, unidade, quantidade, preco, fornecedor)
VALUES
  ('PRD-1001','Produto Exemplo A','un', 120.000, 15.50, 'Fornecedor A'),
  ('PRD-1002','Produto Exemplo B','kg', 50.500, 42.00, 'Fornecedor B'),
  ('PRD-1003','Produto Exemplo C','m', 200.000, 3.75, 'Fornecedor C');
