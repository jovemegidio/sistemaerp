const http = require('http');
function get(path){
  return new Promise((resolve,reject)=>{
  const port = process.env.PORT ? parseInt(process.env.PORT,10) : 3001;
  const opts = { hostname: 'localhost', port: port, path, method: 'GET', headers: { 'Accept': 'application/json' } };
    const req = http.request(opts, res=>{
      let data='';
      res.setEncoding('utf8');
      res.on('data', chunk=> data+=chunk);
      res.on('end', ()=> resolve({ status: res.statusCode, body: data }));
    });
    req.on('error', err=> reject(err));
    req.end();
  });
}
(async ()=>{
  try{
    console.log('GET /api/pcp/pedidos/faturados');
    console.log(await get('/api/pcp/pedidos/faturados'));
    console.log('\nGET /api/pcp/pedidos/prazos');
    console.log(await get('/api/pcp/pedidos/prazos'));
    console.log('\nGET /api/pcp/acompanhamento');
    console.log(await get('/api/pcp/acompanhamento'));
    process.exit(0);
  }catch(e){
    console.error('check failed', e && e.message? e.message : e);
    process.exit(2);
  }
})();
