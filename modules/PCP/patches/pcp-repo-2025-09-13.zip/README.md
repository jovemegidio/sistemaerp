PCP - Instruções rápidas

Como iniciar o servidor localmente:

1) Instalar dependências (se ainda não):

```powershell
npm install
```

2) Iniciar o servidor:

```powershell
npm start
```

3) Health check:

Abra no navegador ou use PowerShell:

```powershell
Invoke-RestMethod http://localhost:3001/health
```

Endpoints úteis:
- /api/pcp/produtos
- /api/pcp/materiais
- /api/pcp/pedidos
- /api/pcp/search?q=<termo>

Resolução de problemas comuns:
- Se `EADDRINUSE` (porta em uso): identifique o PID com `netstat -ano | Select-String ":3001"` e finalize com `Stop-Process -Id <PID>` no PowerShell.
- Se o navegador não conectar: verifique firewall/antivírus que possam bloquear portas locais.

Se quiser, eu adiciono um script `dev` que reinicia automaticamente com `nodemon` (precisa instalar `nodemon`).
